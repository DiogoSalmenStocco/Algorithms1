#include "Fila.h"
#include "Lista.h"
#include "Pilha_hist.h"
#include <stdio.h>
#include <stdlib.h>

void registrar_paciente(int id, char *nome);